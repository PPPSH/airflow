import sys
import os

from datahub.emitter.mcp import MetadataChangeProposalWrapper
from datahub.emitter.rest_emitter import DatahubRestEmitter
from datahub.metadata.com.linkedin.pegasus2avro.dataset import (
    DatasetLineageType,
    UpstreamLineage,
    UpstreamClass,
)
import constants as cs
from lineage.common import function as fc

"""
주의사항: 테이블명은 소문자로 입력해야 정상 적용 됩니다.
"""

# 1. python 파일 실행을 위한 path 설정 (본인 로컬 PC 경로로 수정)
sys.path.append("D:\Project\data-catalog-lineage-template")

# 2. 업스트림 테이블 정의
upstream_table_dict = {
    "01": {
        "table": "a1_tes.itscls_jh_daily_pred_results_hbase10_disconn_test",
        "cols": ["jpg", "classr"],
    },
    "02": {
        "table": "a1_tes.itscls_jh_daily_pred_results_hbase10_fe_test",
        "cols": ["nas_ip", "hbase_img_path"],
    },
}

# 3. 다운스트림 테이블 정의
downstream_table_dict = {
    "table": "a1_tes.itscls_jh_daily_pred_results_hbase10_pm_20240426",
    "cols": [
        "jpg",
        "classr",
        "nas_ip",
        "hbase_img_path",
    ],
}

# 5. lineage data 생성
data = [
    {
        "upstream_table": upstream_table_dict["01"]["table"],
        "upstream_field": upstream_table_dict["01"]["cols"][0],
        "downstream_table": downstream_table_dict["table"],
        "downstream_field": downstream_table_dict["cols"][0],
    },
    {
        "upstream_table": upstream_table_dict["01"]["table"],
        "upstream_field": upstream_table_dict["01"]["cols"][1],
        "downstream_table": downstream_table_dict["table"],
        "downstream_field": downstream_table_dict["cols"][1],
    },
    {
        "upstream_table": upstream_table_dict["02"]["table"],
        "upstream_field": upstream_table_dict["02"]["cols"][0],
        "downstream_table": downstream_table_dict["table"],
        "downstream_field": downstream_table_dict["cols"][2],
    },
    {
        "upstream_table": upstream_table_dict["02"]["table"],
        "upstream_field": upstream_table_dict["02"]["cols"][1],
        "downstream_table": downstream_table_dict["table"],
        "downstream_field": downstream_table_dict["cols"][3],
    },
]


# 6. lineage 객체 생성
fineGrainedLineages = fc.create_fine_grained_lineages(data)

# 7. upstream 객체 리스트 정의
upstreams = [
    UpstreamClass(
        dataset=fc.datasetUrn(upstream_table_dict["01"]["table"]),
        type=DatasetLineageType.TRANSFORMED,
    ),
    UpstreamClass(
        dataset=fc.datasetUrn(upstream_table_dict["02"]["table"]),
        type=DatasetLineageType.TRANSFORMED,
    ),
]

# 8. upstream 컬럼(필드) 객체 생성
fieldLineages = UpstreamLineage(
    upstreams=upstreams, fineGrainedLineages=fineGrainedLineages
)

# 9. metadata 변경사항 적용을 위한 객체 생성
lineageMcp = MetadataChangeProposalWrapper(
    entityUrn=fc.datasetUrn(downstream_table_dict["table"]),
    aspect=fieldLineages,
)

# 10. GMS REST API에 emitter 객체 생성
emitter = DatahubRestEmitter(
    cs.DATAHUB_GMS_URL,
    token=cs.ACCESS_TOKEN,
)

# 11. GMS 서버에 lineage 적용
emitter.emit_mcp(lineageMcp)
