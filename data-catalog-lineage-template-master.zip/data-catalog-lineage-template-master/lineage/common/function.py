import datahub.emitter.mce_builder as builder
from datahub.metadata.com.linkedin.pegasus2avro.dataset import (
    FineGrainedLineage,
    FineGrainedLineageDownstreamType,
    FineGrainedLineageUpstreamType,
)
from typing import List, Dict


def datasetUrn(tbl):
    return builder.make_dataset_urn("hive", tbl)


def fldUrn(tbl, fld):
    return builder.make_schema_field_urn(datasetUrn(tbl), fld)


def create_fine_grained_lineages(data: List[dict]) -> List[FineGrainedLineage]:
    lineages = []
    for entry in data:
        lineage = FineGrainedLineage(
            upstreamType=FineGrainedLineageUpstreamType.FIELD_SET,
            upstreams=[fldUrn(entry["upstream_table"], entry["upstream_field"])],
            downstreamType=FineGrainedLineageDownstreamType.FIELD,
            downstreams=[fldUrn(entry["downstream_table"], entry["downstream_field"])],
        )
        lineages.append(lineage)
    return lineages
