# data-catalog-lineage-template



## Getting started

1. 템플릿 코드 git repository copy 후 신규 repository  생성
2. datahub 패키지 설치를 위한 로컬 Python 가상환경 생성
   - [가상환경 설정 참고](https://velog.io/@tls0506/Windows-Python-%ED%99%98%EA%B2%BD-%EC%84%A4%EC%A0%95-venv-%EA%B0%80%EC%83%81-%ED%99%98%EA%B2%BD-formattor-linter)
3. pip install acryl-datahub
4. template.py 코드 수정
5. python template.py


